import React from 'react'

export default function PageLoader() {
  return (
    <div id="page-loader">
      <div id="loader-bar"></div>
    </div>
  )
}
